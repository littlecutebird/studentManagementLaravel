

<?php $__env->startSection('content'); ?>
<div class="page-header">
    <h1>Edit message</h1>
</div>
<div class="container">
    <form action='<?php echo e(route('editMsg', ['id' => $message -> id, 'receiveId' => $receiveId])); ?>' method='post'>
    <?php echo csrf_field(); ?>
        <div class="input-group">
        <input type="text" style=' background: linear-gradient(to left, #ffefba, #ffffff);font-size:15px;font-weight:550;color: black;' class="form-control " placeholder="Send new messeage" name='messageContent' value='<?php echo e($message -> content); ?>' required>
            <span class="input-group-btn">
                <button style="background: linear-gradient(to right, #f12711, #f5af19);" type="submit" class="btn btn-default">
                    <span class="glyphicon glyphicon-send"></span>
                </button>
            </span>
         </div>  
    </form>    
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('templates.template', ['title' => 'Edit message'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\studentManagementLaravel\resources\views/users/editMsg.blade.php ENDPATH**/ ?>