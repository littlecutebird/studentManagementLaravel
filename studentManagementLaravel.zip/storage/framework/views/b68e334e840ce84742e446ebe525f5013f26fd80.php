

<?php $__env->startSection('content'); ?>
<div class="page-header">
    <h1>Edit student profile</h1>
</div>
<div class="container">
    <form action="<?php echo e(route('editStudentProfile', ['id' => $user -> id])); ?>" method="post">
    <?php echo csrf_field(); ?>    
        <?php if(session() -> has('editSuccess')): ?>
        <div class='alert alert-success'>Update student profile success!</div>
        <?php endif; ?>
        <div class="form-group">
            <label>Fullname: </label>
            <input class="form-control" type="text" name="fullname" value="<?php echo e($user -> fullname); ?>">
            <?php $__errorArgs = ['fullname'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <span class='help-block'><?php echo e($message); ?></span>  
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <div class="form-group">
            <label>Email: </label>
            <input class="form-control" type="email" name="email" value="<?php echo e($user -> email); ?>">
            <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <span class='help-block'><?php echo e($message); ?></span>  
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <div class="form-group">
            <label>Phone number: </label>
            <input class="form-control" type="tel" name="phonenumber" value="<?php echo e($user -> phonenumber); ?>" pattern="[0-9]{7,10}">
            <?php $__errorArgs = ['phonenumber'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <span class='help-block'><?php echo e($message); ?></span>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <button class="btn btn-success" type='submit'>Confirm</button>
    </form>
    
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('templates.template', ['title' => 'Edit student profile'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\studentManagementLaravel\resources\views/users/editStudentProfile.blade.php ENDPATH**/ ?>