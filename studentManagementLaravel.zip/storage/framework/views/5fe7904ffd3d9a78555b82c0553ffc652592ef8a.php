

<?php $__env->startSection('content'); ?>
<div class="page-header">
    <h1>Add new challenge</h1>
</div>
<div class='container'>
    <form action='<?php echo e(route('addChallenge')); ?>' method='post' enctype='multipart/form-data'>
    <?php echo csrf_field(); ?> 
        <?php if(session() -> has('error')): ?>
        <div class='alert alert-danger'><?php echo e(Session::get('error')); ?></div>
        <?php endif; ?>
        <div class='form-group'>
            <label for='title'>Title:</label>
            <input type='text' id='title' name='title' required><br>
            <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <span class='help-block'><?php echo e($message); ?></span>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <div class='form-group'>
            <label for='hint'>Hint: </label>
            <input id='hint' name='hint' placeholder='Enter hint here' required><br>
            <?php $__errorArgs = ['hint'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <span class='help-block'><?php echo e($message); ?></span>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <div class='form-group'>
            <label for='deadline'>Deadline:</label>
            <input type='datetime-local' id='deadline' name='deadline' required> <br>
            <?php $__errorArgs = ['deadline'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <span class='help-block'><?php echo e($message); ?></span>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <div class='form-group'>
            <label for='fileToUpload'>Select file to upload:</label>
            <input type="file" name="fileToUpload" id="fileToUpload" required> <br>
            <span class='help-block'>The file must be a txt file, the filename should be the answer to the challenge</span>
        </div>
        <div class='form-group'>
            <button type="submit" class="btn btn-success" value="Upload File" name="addNew">Add new challenge</button>  
            <button class='btn btn-warning' type='reset'>Reset</button>
            <a class='btn btn-primary' href='<?php echo e(route('listChallenge')); ?>'>Cancel</a>
        </div>
    </form>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('templates.template', ['title' => 'Add new challenge'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\studentManagementLaravel\resources\views/challenges/addChallenge.blade.php ENDPATH**/ ?>