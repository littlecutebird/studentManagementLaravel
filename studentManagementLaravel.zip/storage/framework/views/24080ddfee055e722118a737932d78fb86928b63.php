

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="center">
        <h2>Sign up</h2>
        <p>Please fill this form to create an account.</p>
        <form action="<?php echo e(route('addStudent')); ?>" method="post">
        <?php echo csrf_field(); ?>
            <div class="form-group">
                <label>Username</label>
                <input type="text" name="username" class="form-control">
            </div>    
            <div class="form-group">
                <label>Password</label>
                <input type="password" name="password" class="form-control">
            </div>
            <div class="form-group">
                <label>Confirm Password</label>
                <input type="password" name="confirm_password" class="form-control">
            </div>
            <div class="form-group">
                <label>Full name</label>
                <input type="text" name="fullname" class="form-control">
            </div>
            <div class="form-group">
                <label>Email</label>
                <input type="text" name="email" class="form-control">
            </div>
            <div class="form-group">
                <label>Phone number</label>
                <input type="text" name="phonenumber" class="form-control">
            </div>
            <div class="form-group">
                <input type="submit" name='submit' class="btn btn-primary" value="Submit">
                <input type="reset" class="btn btn-default" value="Reset">
            </div>
        </form>
    </div>   
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('templates.template', ['title' => 'Add new student'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\studentManagementLaravel\resources\views/register.blade.php ENDPATH**/ ?>