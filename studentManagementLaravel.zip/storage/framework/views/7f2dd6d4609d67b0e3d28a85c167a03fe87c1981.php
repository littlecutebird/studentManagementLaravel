
<?php $__env->startSection('content'); ?>
<div class='page-header'>
    <h1>Welcome to our site</h1>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('templates.template', ['title' => 'Index'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\studentManagementLaravel\resources\views/index.blade.php ENDPATH**/ ?>