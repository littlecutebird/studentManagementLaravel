

<?php $__env->startSection('content'); ?>
<div class="page-header">
    <h1>See student's submissions</h1>
</div>
<div class='container'>
    <div class="panel panel-success">
        <div class="panel-heading"><?php echo e($exercise -> title); ?></div>
        <div class='panel-body'><?php echo e($exercise -> description); ?></div>
        <div class="panel-body"><a role='button' class='btn btn-warning' href='<?php echo e(asset($exercise -> file_path)); ?>'>Statement</a></div>
    </div>
    <div class="panel panel-primary">
        <div class="panel-heading">Student submissions</div>
        <div class="panel-body">
        <?php $__currentLoopData = $submissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $submission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class='panel panel-info'>
                <div class='panel-heading'><?php echo e($submission -> user -> fullname); ?></div>
                <div class='panel-body'><?php echo e($submission -> submit_time); ?></div>
                <div class='panel-body'><a role='button' class='btn btn-warning' href='<?php echo e(asset($submission -> file_path)); ?>'>File submission</a></div>
            </div> 
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
       
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('templates.template', ['title' => 'See submissions'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\studentManagementLaravel\resources\views/exercises/seeSubmissions.blade.php ENDPATH**/ ?>