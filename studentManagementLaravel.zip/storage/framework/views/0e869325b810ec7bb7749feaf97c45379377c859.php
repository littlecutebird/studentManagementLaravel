

<?php $__env->startSection('content'); ?>
<div class="page-header">
    <h1>All exercises</h1>
</div>

<?php if(Auth::user() -> type == 'teacher'): ?>
<div class='container'>
    <a class='btn btn-success' href='<?php echo e(route('addExercise')); ?>'>Add new exercise</a>
</div>
<br>
<?php endif; ?>

<div class="container panel-group">
    <?php if(session() -> has('deleteSuccess')): ?>
    <div class='alert alert-danger'>Delete exercise success!</div>
    <?php endif; ?>
    <?php $__currentLoopData = $exercises; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $exercise): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class='panel panel-primary'>
        <div class='panel-heading'><?php echo e($exercise -> title); ?></div>
        <div class='panel-body'>Deadline: <?php echo e($exercise -> deadline); ?></div>
        <?php if(Auth::user() -> type == 'student'): ?>
        <div class='panel-body'>Status: <?php echo e(isset($submitStatus[$exercise -> id]) ? 'Submitted' : 'Not done'); ?></div>
        <div class='panel-body'><a class='btn btn-success' href='<?php echo e(route('submitExercise', ['id' => $exercise -> id])); ?>'>Submit</a></div>
        <?php elseif(Auth::user() -> type == 'teacher'): ?>
        <div class='panel-body'>
            <form class='form-inline'>
                <a class='btn btn-info btn-inline' href='<?php echo e(route('seeSubmissions', ['exerciseId' => $exercise -> id])); ?>'>See submissions</a>
                <a class='btn btn-danger btn-inline' href='<?php echo e(route('deleteExercise', ['id' => $exercise -> id])); ?>' onclick="return confirm('Are you sure you want to delete this exercise?')">Delete exercise</a>
            </form>
        </div>
        <?php endif; ?>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('templates.template', ['title' => 'List exercise'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\studentManagementLaravel\resources\views/exercises/listExercise.blade.php ENDPATH**/ ?>