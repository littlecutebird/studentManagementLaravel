

<?php $__env->startSection('content'); ?>
<div class="page-header">
    <h1>My profile</h1>
</div>
<div class='container'>
    <div class="panel panel-success">
        <div class="panel-heading">Full name: <?php echo e($user -> fullname); ?></div>
        <div class="panel-body">Email: <?php echo e($user -> email); ?></div>
        <div class="panel-body">Phone number: <?php echo e($user -> phonenumber); ?></div>
        <div class="panel-body">Account type: <?php echo e($user -> type); ?></div>
    </div>
</div>

<div class="container">
    <a href="<?php echo e(route('editProfile')); ?>" class="btn btn-primary">Edit profile</a>
    <a href="<?php echo e(route('changePassword')); ?>" class="btn btn-info">Change password</a>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('templates.template', ['title' => 'Profile'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\studentManagementLaravel\resources\views/profile/profile.blade.php ENDPATH**/ ?>