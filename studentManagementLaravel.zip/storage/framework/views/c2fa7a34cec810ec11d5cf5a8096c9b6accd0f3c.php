<nav class="navbar navbar-inverse navbar-fixed-top">
    <div class="container-fluid">
        <div class="navbar-header">
            <a class="navbar-brand" href="<?php echo e(route('index')); ?>"><img src='<?php echo e(asset('img/cat-logo.jpg')); ?>' alt='website logo' height='30' width='30'></a>
        </div>
        <ul class="nav navbar-nav">
            <li <?php if(Request::is('/')): ?> class="active" <?php endif; ?>><a href="<?php echo e(route('index')); ?>">Home</a></li>
            <li <?php if(Request::is('exercises*')): ?> class="active" <?php endif; ?>><a href="<?php echo e(route('listExercise')); ?>">Exercise</a></li>
            <li <?php if(Request::is('challenges*')): ?> class="active" <?php endif; ?>><a href="<?php echo e(route('listChallenge')); ?>">Challenge</a></li>
            <li <?php if(Request::is('users*')): ?> class="active" <?php endif; ?>><a href="<?php echo e(route('listUser')); ?>">List user</a></li>
        </ul>
        <ul class="nav navbar-nav navbar-right">
            <li <?php if(Request::is('profile*')): ?> class="active" <?php endif; ?>><a href="<?php echo e(route('profile')); ?>"><span class="glyphicon glyphicon-user"></span> Profile</a></li>
            <li><a href="<?php echo e(route('logout')); ?>"><span class="glyphicon glyphicon-log-out"></span> Logout</a></li>
        </ul>
    </div>
</nav><?php /**PATH C:\xampp\htdocs\studentManagementLaravel\resources\views/templates/header.blade.php ENDPATH**/ ?>