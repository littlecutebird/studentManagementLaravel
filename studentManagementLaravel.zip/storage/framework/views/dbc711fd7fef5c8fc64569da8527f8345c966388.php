

<?php $__env->startSection('content'); ?>
<div class='page-header'>
    <h1>Submit homework</h1>
</div>
<div class='container'>
    <div class='row'>
        <div class='col-lg-6'>
            <div class='panel panel-primary'>
                <div class="panel-heading"><?php echo e($exercise -> title); ?></div>
                <div class="panel-body"><i><?php echo e($exercise -> description); ?></i></div>
                <div class='panel-body'>Last modified time: <?php echo e($exercise -> updated_at); ?></div>
                <div class='panel-body'>Deadline: <?php echo e($exercise -> deadline); ?></div>
                <div class='panel-body'><a class='btn btn-warning' href='<?php echo e(asset('storage/'. $exercise -> file_path)); ?>'>Statement</a></div>
            </div>
        </div>
        <div class='col-lg-6'>
            <br>
            <form action='' method='post' enctype='multipart/form-data'>
            <?php echo csrf_field(); ?>
                <div class='form-group'>
                    <label for='fileToUpload'>Select file to upload:</label>
                    <input class='form-control' type="file" name="fileToUpload" id="fileToUpload" required>
                    <?php $__errorArgs = ['fileToUpload'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class='help-block'><?php echo e($message); ?></span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <input class='btn btn-success' type="submit" value="Submit homework" name="submit">
            </form>

        </div>
    </div>
   
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('templates.template', ['title' => 'Submit exercise'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\studentManagementLaravel\resources\views/exercises/submitExercise.blade.php ENDPATH**/ ?>