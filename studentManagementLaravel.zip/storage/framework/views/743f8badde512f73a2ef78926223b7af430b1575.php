

<?php $__env->startSection('content'); ?>
<div class="page-header">
    <h1>Chat with <?php echo e($receiverUser -> fullname); ?></h1>
</div>

<style>
    .well {
        margin:auto;
        font-size:15px;
        font-weight:550;
        color: #f3f3f3;
        border-bottom-left-radius: 1.3em;
        border-bottom-right-radius: 1.3em;
        border-top-left-radius: 1.3em;
        border-top-right-radius: 1.3em;
        background-color: #1fc8db;
        background-image: linear-gradient(140deg, #EADEDB 0%, #BC70A4 50%, #BFD641 75%);
    }
</style>
<div class='container'>
<?php $__currentLoopData = $messages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php if($message -> sendId == Auth::user() -> id): ?>
    <div class='media'>
        <div class='media-body text-right'>
            <h3 class='media-heading'><?php echo e(Auth::user() -> fullname); ?></h3>
            <div class='well'><?php echo e($message -> content); ?></div>
            
            <a href='<?php echo e(route('editMsg', ['id' => $message -> id, 'receiveId' => $message -> receiveId])); ?>'>
                <span class='glyphicon glyphicon-pencil' style='color:white'></span>
            </a>
            <a onclick="return confirm('Are you sure you want to delete this message?')" href='<?php echo e(route('deleteMsg', ['id' => $message -> id])); ?>'>
                <span class='glyphicon glyphicon-minus' style='color:red'></span>
            </a> &#160
        </div>
        <div class='media-right media-top'>
            <img src='<?php echo e(asset('img/sendMsg-logo.png')); ?>' class='media-object' style='width:80px'>
        </div>
    </div>
    <?php elseif($message -> sendId = $receiverUser -> id): ?>
    <div class='media'>
        <div class='media-left media-top'>
            <img src='<?php echo e(asset('img/receiveMsg-logo.png')); ?>' class='media-object' style='width:80px'>
        </div>
        <div class='media-body'>
            <h3 class='media-heading'><?php echo e($receiverUser -> fullname); ?></h3>
            <div class='well'><?php echo e($message['content']); ?></div>           
        </div>
    </div>
    <?php endif; ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <div id="bottomPage" >
        <br>
        <form action='<?php echo e(route('sendMsg', ['id' => $receiverUser -> id])); ?>' method='post'>
        <?php echo csrf_field(); ?>
            <div class="input-group">
                <input type="text" style='background: linear-gradient(to left, #ffefba, #ffffff);font-size:15px;font-weight:550;color: black;' class="form-control " placeholder="Send new messeage" name='messageContent' required>
                <span class="input-group-btn">
                    <button style="background: linear-gradient(to right, #f12711, #f5af19);" type="submit" name='newMessage' class="btn btn-default">
                        <span class="glyphicon glyphicon-send"></span>
                    </button>
                </span>
            </div>  
        </form>     
    </div>
    <br>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('templates.template', ['title' => 'Chat'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\studentManagementLaravel\resources\views/users/sendMsg.blade.php ENDPATH**/ ?>