

<?php $__env->startSection('content'); ?>
<div class="page-header">
    <h1>All Challenges</h1>
</div>


<?php if(Auth::user() -> type == 'teacher'): ?>

<?php if(session() -> has('addSuccess')): ?>
<div class='container alert alert-success'>Add challenge success!</div>
<?php endif; ?>
<?php if(session() -> has('deleteSuccess')): ?>
<div class='container alert alert-danger'>Delete challenge success!!</div>
<?php endif; ?>

<div class='container'>
    <a class='btn btn-success' href='<?php echo e(route('addChallenge')); ?>'>Add new challenge</a>
</div>

<?php endif; ?>

<?php $__currentLoopData = $challenges; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $challenge): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class='container'>
    <h2><?php echo e($challenge -> title); ?></h2>
    <p>Hint: <?php echo e($challenge -> hint); ?></p>
    <p>Deadline: <?php echo e($challenge -> deadline); ?></p>
    <?php if(Auth::user() -> type == 'student'): ?>
    <a class='btn btn-danger' href='<?php echo e(route('submitChallenge', ['challengeId' => $challenge -> id])); ?>'>Submit</a>
    <?php elseif(Auth::user() -> type == 'teacher'): ?>
    <form class='form-inline'>
        <a class='btn btn-danger btn-inline' href='<?php echo e(route('deleteChallenge', ['challengeId' => $challenge -> id])); ?>' onclick="return confirm('Are you sure you want to delete this homework?')">Delete challenge</a>
    </form>
    <?php endif; ?>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('templates.template', ['title' => 'List challenge'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\studentManagementLaravel\resources\views/challenges/listChallenge.blade.php ENDPATH**/ ?>