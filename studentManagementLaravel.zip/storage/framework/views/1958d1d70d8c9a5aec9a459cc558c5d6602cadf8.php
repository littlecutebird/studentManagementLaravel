

<?php $__env->startSection('content'); ?>
<div class='page-header'>
    <h1>Submit answer</h1>
</div>
<div class='container'> 
    <h2><?php echo e($challenge -> title); ?></h2>
    <p>Hint: <?php echo e($challenge -> hint); ?></p>
    <p>Deadline: <?php echo e($challenge -> deadline); ?></p>
    <form action='<?php echo e(route('submitChallenge', ['challengeId' => $challenge -> id])); ?>' method='post'>
    <?php echo csrf_field(); ?>
        <div class="form-group">
            <label for="answer">Answer: </label>
            <input class='form-control' type="text" name="answer" id="answer" required>
            <?php if(Session() -> has('wrongAnswer')): ?>
            <span class='help-block alert alert-danger'>Wrong answer!</span> 
            <?php endif; ?>
        </div>
        <button class='btn btn-danger' type="submit" name="submitChallenge">Submit answer</button>
        <a class='btn btn-primary' href='<?php echo e(route('listChallenge')); ?>'>Back</a>
    </form>     
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('templates.template', ['title' => 'Submit challenge'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\studentManagementLaravel\resources\views/challenges/submitChallenge.blade.php ENDPATH**/ ?>