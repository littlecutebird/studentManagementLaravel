

<?php $__env->startSection('content'); ?>
<div class='page-header'>
    <h1>Change password</h1>
</div>
<div class="container">
    <p>Please fill in your old and your new password</p>
    <form action="<?php echo e(route('changePassword')); ?>" method="post" >
        <?php echo csrf_field(); ?>
        <?php if(session() -> has('changeSuccess')): ?>
        <div class='alert alert-success'>Change password success!</div>
        <?php endif; ?>
        <div class="form-group">
            <label for="oldPassword">Old password:</label>
            <input class="form-control" type="password" id="oldPassword" name="oldPassword" placeholder="Enter your old password" required>
            <?php $__errorArgs = ['oldPassword'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <span class='help-block'><?php echo e($message); ?></span>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <div class="form-group">
            <label for="newPassword">New password:</label>
            <input class="form-control" type="password" id="newPassword" name="newPassword" placeholder="Enter your new password" required>
            <?php $__errorArgs = ['newPassword'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <span class='help-block'><?php echo e($message); ?></span>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <div class="form-group">
            <label for="confirmPassword">Confirm new password:</label>
            <input class="form-control" type="password" id="confirmPassword" name="confirmPassword" placeholder="Confirm your new password" required>
            <?php $__errorArgs = ['confirmPassword'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <span class='help-block'><?php echo e($message); ?></span>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <button type="submit" class="btn btn-primary">Change password</button>
    </form>
    <script type="text/javascript">
        var password = document.getElementById("newPassword"), confirm_password = document.getElementById("confirmPassword");

        function validatePassword(){
          if(newPassword.value != confirmPassword.value) {
            confirmPassword.setCustomValidity("Passwords Don't Match");
          } else {
            confirmPassword.setCustomValidity('');
          }
        }

        newPassword.oninput = validatePassword;
        confirmPassword.oninput = validatePassword;
    </script>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('templates.template', ['title' => 'Change password'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\studentManagementLaravel\resources\views/users/changePassword.blade.php ENDPATH**/ ?>