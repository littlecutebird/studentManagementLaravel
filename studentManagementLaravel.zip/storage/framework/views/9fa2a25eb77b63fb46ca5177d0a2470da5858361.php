

<?php $__env->startSection('content'); ?>
<div class="page-header">
    <h1>List user in this website</h1>
</div>


<?php if(Auth::user() -> type == "teacher"): ?> 
<div class='container'>
<a class='btn btn-success' href='<?php echo e(route('addStudent')); ?>'>Add new student</a>
</div>
<br>
<?php endif; ?>


<div class="container panel-group">   
<?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class='panel panel-success'>
        <div class='panel-heading'>Full name: <?php echo e($user -> fullname); ?> </div>
        <div class='panel-body'>Email: <?php echo e($user -> email); ?> </div>
        <div class='panel-body'>Phone number: <?php echo e($user -> phonenumber); ?> </div>
        <div class='panel-body'>Account type: <?php echo e($user -> type); ?> </div>
        <div class='panel-body'>
            <a class='btn btn-info' href='#'>Message me</a>
        
        <?php if(Auth::user() -> type == "teacher"): ?> 
        <button class='btn btn-danger' style='float:right;' onclick="return confirm('Are you sure you want to delete this account?')"><a style='color:white' href='#'>Delete account</a></button>
        <a class='btn btn-primary' href='#' style='float:right'>Edit profile</a>
        <?php endif; ?>
        </div>
    </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('templates.template', ['title' => 'List user'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\studentManagementLaravel\resources\views/listUser.blade.php ENDPATH**/ ?>