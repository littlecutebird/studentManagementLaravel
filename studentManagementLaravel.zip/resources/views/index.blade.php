@extends('templates.template', ['title' => 'Index'])
@section('content')
<div class='page-header'>
    <h1>Welcome to our site</h1>
</div>
@endsection